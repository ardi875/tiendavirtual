<?php

/**
 * @author		Miguel Angel Macias Burgos
 * @company 	WBT
 * @copyright 	2026
 * @version     1.0
 */

// Categorias
$listaCategorias = array();
$listaCategorias[] = array("codigo_cat" => 100, "nombre" => "Lacteos");
$listaCategorias[] = array("codigo_cat" => 200, "nombre" => "Carnes");
//$listaCategorias[] = array("codigo_cat" => 300, "nombre" => "Bebidas");
$listaCategorias[] = array("codigo_cat" => 400, "nombre" => "Postres");

// Cod Producto, Nombre, Precio, Stock
$producto = array("codigo" => 1, "nombre" => "Leche Pil 1Lt", "stock" => "50", "precio" => 8, "codigo_cat" => 100);
$producto2 = array("codigo" =>17, "nombre" => "Leche Delizia 1Lt", "precio" =>7, "stock" =>"80", "codigo_cat" => 100);
$producto3 = array("codigo" =>42, "nombre" =>"Yogourt Bebible 1Lt", "stock" =>"24" , "precio" =>12, "codigo_cat" => 100);

$listaProductos = array();
$listaProductos[] = $producto;
$listaProductos[] = $producto2;
$listaProductos[] = $producto3;
$listaProductos[] = array("codigo" => 21, "nombre" => "Pollo sofia", "precio" => 15, "stock" => 20, "codigo_cat" => 200);
$listaProductos[] = array("codigo" => 420, "nombre" => "Coca cola 2 lts", "precio" => 13, "stock" => 100, "codigo_cat" => 300);
$listaProductos[] = array("codigo" => 151, "nombre" => "Pie de manzana", "precio" => 40, "stock" => 20, "codigo_cat" => 400);

// Carnes
$lista2 = array("Res", "Pollo", "Cerdo");
$precios2 = array(40, 15, 27);

?>