<?php

/**
 * @author		Miguel Angel Macias Burgos
 * @company 	WBT
 * @copyright 	2026
 * @version     1.0
 */

require_once "config.php";
require_once "data.php";

// Recibir datos del form
$fecha = $_POST["fecha"]; // YYYY-mm-dd

// covertir en array
$arrayFecha = explode("-", $fecha);
$fecha = $arrayFecha[2]. "/". $arrayFecha[1] . "/" . $arrayFecha[0];  // dd/mm/YYYY

$cliente = $_POST["cliente"];

$nroVenta = "#" . rand(1, 1000);

$i = 0;
$total = 0;
foreach($listaCategorias as $categoria){
    $i++;
    $nomCategoria = $categoria["nombre"];

    $cantidad = $_POST["cantidad-" . $i];
    if ($cantidad != ""){
        $valueControlProd = $_POST[$nomCategoria];
        if ($valueControlProd > 0){
            
            foreach($listaProductos as $producto){
                $nomProducto = $producto["nombre"];
                $codProducto = $producto["codigo"];
                $precioProducto = $producto["precio"];

                if ($codProducto == $valueControlProd){
                    // Producto encontrado = item seleccionado del combo (select)
                    $subtotal = $cantidad * $precioProducto;
                    $total += $subtotal;
                }
            }
        }
    }
}

echo "Total:" . $total;

?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv='content-type' content='text/html' charset='utf-8' />
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
    
	<title><?php echo $appTitle; ?></title>
        
    <!-- CSS -->
    <link rel='stylesheet' href='css/main.css' />        
</head>

<body>

<!-- Main Page -->
<div class='ctn-form'>
    <!-- Header -->
    <div class='form-header'>
        <div class='ctn-icon'><div class='icon'></div></div>
        <div class='form-title'><?php echo $appTitle ?></div>
        <div class='form-subtitle'><?php echo $appSubtitle ?></div>
        <div class='bar'><div class='step'></div></div>
        
        <a href='index.php'><div class='btn-back'></div></a>
    </div>
    <!-- Body -->
    <div class='form-content'>
        <div class='x-2'>
            <div class='card'>
                <div class='card-title'>Nro Venta</div>
                <div class='card-subtitle'><?php echo $nroVenta ?></div>
                <div class='clear'></div>
            </div>
        </div>
        <div class='x-2'>
            <div class='card'>
                <div class='card-title'>Fecha de Venta</div>
                <div class='card-subtitle'><?php echo $fecha ?></div>
                <div class='clear'></div>
            </div>
        </div>
        <div class='x-1'>
            <div class='card'>
                <div class='card-title'>Cliente</div>
                <div class='card-subtitle'><?php echo $cliente ?></div>
                <div class='clear'></div>
            </div>
        </div>
        <div class='x-2'>
            <div class='card'>
                <div class='card-title'>Importe Total</div>
                <div class='card-subtitle'><?php echo $total ?> Bs</div>
                <div class='clear'></div>
            </div>
        </div>
        <div class='clear'></div>
    </div>
</div>

</body>
</html>