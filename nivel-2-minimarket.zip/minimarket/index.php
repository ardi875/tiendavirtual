<?php

/**
 * @author		Miguel Angel Macias Burgos
 * @company 	WBT
 * @copyright 	2026
 * @version     1.0
 */

require_once "config.php";
require_once "data.php";

$fecha = date("Y-m-d");

/*echo count($listaProductos);
for($i=0; $i < count($listaProductos); $i++){
    echo "<br>". $listaProductos[$i]["nombre"] . " - precio: " . $listaProductos[$i]["precio"];
}
echo "<hr>";*/

$cbos = "";
// Lista de categorias
$i = 0;

foreach($listaCategorias as $categoria){
    $i++;
    $codCategoria = $categoria["codigo_cat"];
    $nomCategoria = $categoria["nombre"];

    $opciones = "<option value='-1'>". $nomCategoria ."</option>";
    foreach($listaProductos as $producto){
        $codProd = $producto["codigo"];
        $nomProd = $producto["nombre"];
        $precioProd = $producto["precio"];
        $codCatProd = $producto["codigo_cat"];

        $texto = $nomProd . " (". $precioProd ." Bs)";
        if ( $codCatProd == $codCategoria ){
            
            $opciones .= "\n<option value='". $codProd ."'>". $texto ."</option>";
        }
    }

    $cbos .= "
    <div class='x-1'>
        <div class='card'>
            <div class='x-2'>
                <select name='". $nomCategoria ."'>
                    ". $opciones ."
                </select>
            </div>
            <div class='x-2'>
                <input type='text' name='cantidad-". $i ."' placeholder='Ingrese una cantidad' />
            </div>
            <div class='clear'></div>
        </div>
    </div>";
}


?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv='content-type' content='text/html' charset='utf-8' />
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
    
	<title><?php echo $appTitle; ?></title>
        
    <!-- CSS -->
    <link rel='stylesheet' href='css/main.css' />        
</head>

<body>

<!-- Main Page -->
<div class='ctn-form'>
    <!-- Header -->
    <div class='form-header'>
        <div class='ctn-icon'><div class='icon'></div></div>
        <div class='form-title'><?php echo $appTitle ?></div>
        <div class='form-subtitle'><?php echo $appSubtitle ?></div>
        <div class='bar'><div class='step'></div></div>        
    </div>
    <!-- Body -->
    <div class='form-content'>
        <form action='request.php' method='post' >
            <div class='x-1'>
                <input type='date' name='fecha' placeholder='Seleccione una fecha' value='<?php echo $fecha ?>' />
            </div>
            <div class='x-1'>
                <input type='text' name='cliente' placeholder='Nombre del cliente' />
            </div>
            
            <?php echo $cbos ?>
            <div class='x-1'>
                <input type='submit' value='Pagar' />
            </div>
            <div class='clear'></div>
        </form>
    </div>
</div>

</body>
</html>