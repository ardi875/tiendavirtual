<?php

/**
 * @author		Miguel Angel Macias Burgos
 * @company 	WBT
 * @copyright 	2026
 * @version     1.0
 */

$appTitle = "Minimarket 3B";
$appSubtitle = "Version 2.0";

?>